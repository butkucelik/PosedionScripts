using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoseidonSink : MonoBehaviour
{

    public float sinkingSpeed = 1f; 

    private void Update()
    {
        transform.Translate(Vector3.down * sinkingSpeed * Time.deltaTime, Space.World);
    }
}
