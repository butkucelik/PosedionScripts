using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trampoline : MonoBehaviour
{
    public Transform platform;
    public float minHeight = 20f;
    public float maxHeight = 40f;
    public float speed = 4f;

    private bool movingUp = true;

    private void Start()
    {
        StartCoroutine(MovePlatform());
    }

    private IEnumerator MovePlatform()
    {
        while (true)
        {
            float targetHeight = movingUp ? maxHeight : minHeight;
            float distance = Mathf.Abs(platform.position.y - targetHeight);

            while (distance > 0.1f)
            {
                float step = speed * Time.deltaTime;
                platform.position = Vector3.MoveTowards(platform.position, new Vector3(platform.position.x, targetHeight, platform.position.z), step);
                distance = Mathf.Abs(platform.position.y - targetHeight);
                yield return null;
            }

            yield return new WaitForSeconds(1f);
            movingUp = !movingUp;
        }
    }
}
