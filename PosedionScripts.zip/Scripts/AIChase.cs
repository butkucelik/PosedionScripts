using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public class AIChase : MonoBehaviour
{
    public Transform player; 
    public float sensingRadius = 10000f; 

    private NavMeshAgent agent; 

    private void Start()
    {
        agent = GetComponent<NavMeshAgent>();
    }

    private void Update()
    {
        // mesafe hesab�
        float distanceToPlayer = Vector3.Distance(transform.position, player.position);

        // radi�sa girdi�inde posumu onun posu yap�yorum
        if (distanceToPlayer <= sensingRadius)
        {
            agent.SetDestination(player.position);
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            // �lme k�sm�
            KillPlayer(other.gameObject);
        }
    }

    private void KillPlayer(GameObject player)
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

    }

}
