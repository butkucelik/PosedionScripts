using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SharkRoaming : MonoBehaviour
{
    public float roamingRange = 10f; 
    public float roamingSpeed = 5f; 

    private Vector3 initialPosition;
    private Vector3 targetPosition;

    private void Start()
    {
        initialPosition = transform.position;
        targetPosition = GenerateRandomRoamingPosition();
    }

    private void Update()
    {
      
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, roamingSpeed * Time.deltaTime);

        if (Vector3.Distance(transform.position, targetPosition) < 0.01f)
        {
            targetPosition = GenerateRandomRoamingPosition();
        }
    }

    private Vector3 GenerateRandomRoamingPosition()
    {
        
        float randomX = Random.Range(initialPosition.x - roamingRange, initialPosition.x + roamingRange);
        float randomZ = Random.Range(initialPosition.z - roamingRange, initialPosition.z + roamingRange);

        return new Vector3(randomX, initialPosition.y, randomZ);
    }

}
