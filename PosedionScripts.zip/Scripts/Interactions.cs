using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Interactions : MonoBehaviour
{
    /*
    public GameObject canvas; 

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            canvas.SetActive(true); 
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            canvas.SetActive(false); 
        }
    }
    */
    public GameObject objectToInteract;
    public GameObject objectToDestroy;
 

    private bool hasInteracted = false;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.E) && !hasInteracted)
        {
            InteractWithObject();
        }
    }

    private void InteractWithObject()
    {
        
        if (objectToInteract != null)
        {
            // buraya ses dosyas� falan atar�m
           

            
            if (objectToDestroy != null)
            {
                Destroy(objectToDestroy);
                Destroy(objectToInteract);
            }
            
            hasInteracted = true;
        }
        
    }
}




