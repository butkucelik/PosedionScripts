using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RisingObject : MonoBehaviour
{
   
    public float speed = 0.9f;

    private void Update()
    {
        // Obje yukar� ��k�yor
        transform.Translate(Vector3.up * speed * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            // �lme k�sm�
            KillPlayer(other.gameObject);
        }
    }

    private void KillPlayer(GameObject player)
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

    }
}
